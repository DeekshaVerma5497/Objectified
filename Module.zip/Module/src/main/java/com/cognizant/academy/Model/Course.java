package com.cognizant.academy.Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



@Entity

@Table(name="course")
public class Course implements Serializable 
{
	public static final long serialVersionUID = 1L;
	private
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	//@SequenceGenerator(name="course_generatorss", sequenceName = "course_seqqq" , initialValue = 1, allocationSize = 1)
	int id;
	String name;
	@OneToMany(mappedBy = "course", cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	private List<Module> listmodule = new ArrayList<Module>();
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String course_name) {
		this.name = course_name;
	}
	public List<Module> getListmodule() {
		return listmodule;
	}
	public void setListmodule(List<Module> listmodule) {
		this.listmodule = listmodule;
	}
	
	
}
