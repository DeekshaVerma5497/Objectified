package com.cognizant.academy.Dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cognizant.academy.Model.Course;
import com.cognizant.academy.Model.Module;
import com.cognizant.academy.Model.Objective;
import com.cognizant.academy.Model.Stack;

@Repository("module_dao")
public class ModuleDaoImpl implements ModuleDao {

	@PersistenceContext
	private EntityManager em;

	public List<Module> getmodlist(String course_id) {
		List<Module> list = new ArrayList<Module>();
		int course = Integer.parseInt(course_id);

		Query query = em.createQuery("from Module where course_id='" + course + "'");
		list = (List<Module>) query.getResultList();
		return list;

	}

	public void add(Module obj) {

		em.persist(obj);

	}

	public List<Stack> getStacklist() {

		List<Stack> list = new ArrayList<Stack>();
		Query query = em.createQuery("from Stack");
		list = (List<Stack>) query.getResultList();
		return list;
	}

	public List<Objective> getModuleObjectives(int mod_id) {

		List<Objective> list = new ArrayList<Objective>();
		Query query = em.createQuery("from Objective where module_id='" + mod_id + "'");
		list = (List<Objective>) query.getResultList();
		return list;
	}

	public List<Objective> getStackObjectives(int stack_id) {
		List<Objective> list = new ArrayList<Objective>();
		Query query = em.createQuery("from Objective where stack_id='" + stack_id + "' and module_id is null");
		list = (List<Objective>) query.getResultList();
		return list;
	}

	public void addObjectiveToModule(int module, int objective) {
		Objective o = em.find(Objective.class, objective);
		Module m = em.getReference(Module.class, module);
		o.setModule(m);

	}

	public void removeObjective(int objective_id) {

		Objective o = em.find(Objective.class, objective_id);
		o.setModule(null);

	}

	public int getStack_id(String stack) {
		List<Stack> list = new ArrayList<Stack>();
		int i = 0;
		Query query = em.createQuery("from Stack where name='" + stack + "'");
		Stack s = (Stack) query.getSingleResult();
		i = s.getId();
		return i;
	}

	public int getModule_id(String module) {
		System.out.println(module);
		int i = 0;
		try {
			Query query = em.createQuery("from Module where name='" + module + "'");
			Module m = (Module) query.getSingleResult();
			if (m != null) {
				i = m.getId();
			}
		} catch (NoResultException e) {
			return 0;

		}
		return i;
	}

	public int getObjective_id(String objective) {
		int i = 0;

		Query query = em.createQuery("from Objective where name='" + objective + "'");
		Objective o = (Objective) query.getSingleResult();
		i = o.getId();
		return i;
	}

//Methods to create table initially for test

	public void insertCourse(Course c) {
		em.persist(c);

	}

	public void insertModule(Module m) {
		em.persist(m);

	}

	public void insertStack(Stack s) {

		em.persist(s);

	}

	public void insertObj(Objective o1) {

		em.persist(o1);

	}

	public Course getCourse(int course_id) {
		Course c = null;
		System.out.println("Phucha idhar");
		c = em.find(Course.class, course_id);
		System.out.println("hello");
		return c;

	}

}
