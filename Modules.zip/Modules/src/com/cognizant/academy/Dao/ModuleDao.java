package com.cognizant.academy.Dao;

import java.util.List;

import com.cognizant.academy.Model.Course;
import com.cognizant.academy.Model.Module;
import com.cognizant.academy.Model.Objective;
import com.cognizant.academy.Model.Stack;

public interface ModuleDao {
	
	public List<Module> getmodlist(String course_id);
	
	public void add(Module obj);
	
	public List<Stack> getStacklist();
	
	public List<Objective> getModuleObjectives(int mod_id);
	
	public List<Objective> getStackObjectives(int stack_id);
	
	public void addObjectiveToModule(int module, int objective);
	
	public void removeObjective(int objective_id);
	
	public int getStack_id(String stack);
	
	public int getModule_id(String module);
	
	public int getObjective_id(String objective);
	
	public void insertCourse(Course c);
	
	public void insertModule(Module m);
	
	public void insertStack(Stack s);
	
	public void insertObj(Objective o1);
	
	public Course getCourse(int course_id);

}
